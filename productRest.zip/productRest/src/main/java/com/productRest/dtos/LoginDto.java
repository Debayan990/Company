package com.productRest.dtos;

public record LoginDto(String usernameOrEmail, String password) {
}
